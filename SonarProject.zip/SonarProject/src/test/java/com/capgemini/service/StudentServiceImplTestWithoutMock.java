package com.capgemini.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.exceptions.DuplicateStudentException;
import com.capgemini.exceptions.NoSuchStudentException;
import com.capgemini.model.Student;
@SpringBootTest
class StudentServiceImplTestWithoutMock {
	@Autowired
	private StudentService service;
	
	@Test
	void testFindStudentByIdShouldReturnStudentObject() throws NoSuchStudentException, DuplicateStudentException {
		Student student = new Student();
		student.setStudentName("Test");
		student.setStudentScore(60);
		
		service.addStudent(student); // this will populate student id
		
		Student result = service.findStudentById(student.getStudentId());
		
		assertEquals(student.getStudentName(), result.getStudentName());
		assertEquals(student.getStudentId(), result.getStudentId());
		assertEquals(student.getStudentScore(), result.getStudentScore());
		
		service.deleteStudent(student.getStudentId());
	}
	
	@Test
	void testFindStudentByIdShouldThrowNoSuchStudentException() {
		assertThrows(NoSuchStudentException.class, ()->{
			service.findStudentById(-1);
		});
	}

}
