package com.capgemini.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.capgemini.dao.StudentRepository;
import com.capgemini.exceptions.DuplicateStudentException;
import com.capgemini.exceptions.NoSuchStudentException;
import com.capgemini.model.Student;
@SpringBootTest
class StudentServiceImplTestWithMock {
	@Autowired
	private StudentService service;
	
	@MockBean
	private StudentRepository repository;
	
	@Test
	void testFindStudentByIdShouldReturnStudentObject() throws NoSuchStudentException, DuplicateStudentException {
		Student student = new Student();
		student.setStudentId(1); // because I am not interacting with database. (auto generated pk )
		student.setStudentName("Test");
		student.setStudentScore(60);
		
		Optional<Student> expected = Optional.of(student);
		when(repository.findById(1)).thenReturn(expected);
		
		Student result = service.findStudentById(student.getStudentId());
		assertEquals(student, result);
		
	}
	
	@Test
	void testFindStudentByIdShouldThrowNoSuchStudentException() {
		assertThrows(NoSuchStudentException.class, ()->{
			service.findStudentById(-1);
		});
	}

}
