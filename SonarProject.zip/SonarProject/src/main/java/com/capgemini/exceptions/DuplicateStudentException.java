package com.capgemini.exceptions;

public class DuplicateStudentException extends Exception {

	public DuplicateStudentException(String message) {
		super(message);
	}

}
