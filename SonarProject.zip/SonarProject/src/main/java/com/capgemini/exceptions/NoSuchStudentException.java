package com.capgemini.exceptions;

public class NoSuchStudentException extends Exception{
	public NoSuchStudentException(String message) {
		super(message);
	}
}
